const cells = document.querySelectorAll('.cell');
const message = document.getElementById('message');
const restartBtn = document.getElementById('restartBtn');

let board = ['', '', '', '', '', '', '', '', ''];
let currentPlayer = 'C';
let running = true;

const winningCombinations = [
  [0,1,2], [3,4,5], [6,7,8], // rader
  [0,3,6], [1,4,7], [2,5,8], // kolumner
  [0,4,8], [2,4,6]           // diagonaler
];

function updateMessage(text) {
  message.textContent = 'GLaDOS: "' + text + '"';
}

function handleCellClick() {
  const index = this.getAttribute('data-index');
  if (board[index] !== '' || !running) return;

  board[index] = currentPlayer;
  updateCell(this, currentPlayer);

  if (checkWin(currentPlayer)) {
    updateMessage(currentPlayer === 'C' 
      ? "Companion Cube dominates!" 
      : "Weighted Storage Cube reigns supreme!");
    running = false;
    return;
  }

  if (board.every(cell => cell !== '')) {
    updateMessage("It's a stalemate! Try again.");
    running = false;
    return;
  }

  currentPlayer = currentPlayer === 'C' ? 'W' : 'C';
  updateMessage(currentPlayer === 'C' 
    ? "Companion Cube's turn." 
    : "Weighted Storage Cube is ready.");
}

function updateCell(cell, player) {
  if (player === 'C') {
    cell.textContent = '🧱'; // Companion Cube (närliggande emoji)
    cell.classList.add('companion');
  } else {
    cell.textContent = '📦'; // Weighted Storage Cube (låda)
    cell.classList.add('weighted');
  }
}

function checkWin(player) {
  return winningCombinations.some(combination => {
    return combination.every(index => board[index] === player);
  });
}

function restartGame() {
  board = ['', '', '', '', '', '', '', '', ''];
  running = true;
  currentPlayer = 'C';
  cells.forEach(cell => {
    cell.innerHTML = '';
    cell.classList.remove('companion', 'weighted');
  });
  updateMessage("Welcome to the Aperture Science Tre i Rad challenge.");
}

cells.forEach(cell => cell.addEventListener('click', handleCellClick));
restartBtn.addEventListener('click', restartGame);

function updateCell(cell, player) {
  const img = document.createElement('img');
  img.src = player === 'C' ? 'assets/img/companion.png' : 'assets/img/weighted.png';
  img.alt = player === 'C' ? 'Companion Cube' : 'Weighted Storage Cube';

  cell.innerHTML = ''; // rensa cellen först
  cell.appendChild(img);
}
