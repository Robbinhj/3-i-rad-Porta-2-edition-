const cells = document.querySelectorAll('.cell');
const message = document.getElementById('message');
const restartBtn = document.getElementById('restartBtn');

let board = ['', '', '', '', '', '', '', '', ''];
let currentPlayer = 'C';
let running = true;

const winningCombinations = [
  [0,1,2], [3,4,5], [6,7,8], // rader
  [0,3,6], [1,4,7], [2,5,8], // kolumner
  [0,4,8], [2,4,6]           // diagonaler
];

function updateMessage(text) {
  message.textContent = 'GLaDOS: "' + text + '"';
}

function handleCellClick() {
  const index = this.getAttribute('data-index');
  if (board[index] !== '' || !running) return;

  board[index] = currentPlayer;
  updateCell(this, currentPlayer);

  if (checkWin(currentPlayer)) {
    updateMessage(currentPlayer === 'C' 
      ? "Companion Cube dominates!" 
      : "Weighted Storage Cube reigns supreme!");
    running = false;
    return;
  }

  if (board.every(cell => cell !== '')) {
    updateMessage("It's a stalemate! Try again.");
    running = false;
    return;
  }

  currentPlayer = currentPlayer === 'C' ? 'W' : 'C';
  updateMessage(currentPlayer === 'C' 
    ? "Companion Cube's turn." 
    : "Weighted Storage Cube is ready.");
}

function updateCell(cell, player) {
  if (player === 'C') {
    cell.textContent = '🧱'; // Companion Cube (närliggande emoji)
    cell.classList.add('companion');
  } else {
    cell.textContent = '📦'; // Weighted Storage Cube (låda)
    cell.classList.add('weighted');
  }
}

function checkWin(player) {
  return winningCombinations.some(combination => {
    return combination.every(index => board[index] === player);
  });
}

function restartGame() {
  board = ['', '', '', '', '', '', '', '', ''];
  running = true;
  currentPlayer = 'C';
  cells.forEach(cell => {
    cell.innerHTML = '';
    cell.classList.remove('companion', 'weighted');
  });
  updateMessage("Welcome to the Aperture Science Tre i Rad challenge.");
}

cells.forEach(cell => cell.addEventListener('click', handleCellClick));
restartBtn.addEventListener('click', restartGame);

function handleCellClick() {
  const index = this.getAttribute('data-index');
  if (board[index] !== '' || !running || currentPlayer !== 'C') return;

  board[index] = 'C';
  updateCell(this, 'C');

  if (checkWin('C')) {
    updateMessage("GLaDOS: 'Congratulations, Companion Cube. You win. This must be a bug.'");
    running = false;
    return;
  }

  if (board.every(cell => cell !== '')) {
    updateMessage("It's a stalemate! Try again.");
    running = false;
    return;
  }

  currentPlayer = 'W';
  updateMessage("GLaDOS is thinking...");
  
  // Fördröjning för AI-illusion
  setTimeout(aiMove, 600);
}

function aiMove() {
  if (!running) return;

  const best = minimax([...board], 'W');
  const aiIndex = best.index;

  board[aiIndex] = 'W';
  const cell = document.querySelector(`.cell[data-index="${aiIndex}"]`);
  updateCell(cell, 'W');

  if (checkWin('W')) {
    updateMessage("GLaDOS: 'I win. Of course.'");
    running = false;
    return;
  }

  if (board.every(cell => cell !== '')) {
    updateMessage("It's a tie. You got lucky.");
    running = false;
    return;
  }

  currentPlayer = 'C';
  updateMessage("Your turn, Companion Cube.");
}

function restartGame() {
  board = ['', '', '', '', '', '', '', '', ''];
  running = true;
  currentPlayer = 'C';
  cells.forEach(cell => {
    cell.innerHTML = '';
    cell.classList.remove('companion', 'weighted');
  });
  updateMessage("Welcome to the Aperture Science Tre i Rad challenge.");
}

function minimax(newBoard, player) {
  const huPlayer = 'C';
  const aiPlayer = 'W';
  const availSpots = newBoard.map((val, i) => val === '' ? i : null).filter(i => i !== null);

  // Kontrollera vinnare
  if (checkWinState(newBoard, huPlayer)) {
    return { score: -10 };
  } else if (checkWinState(newBoard, aiPlayer)) {
    return { score: 10 };
  } else if (availSpots.length === 0) {
    return { score: 0 };
  }

  const moves = [];

  for (let i = 0; i < availSpots.length; i++) {
    const move = {};
    move.index = availSpots[i];
    newBoard[availSpots[i]] = player;

    if (player === aiPlayer) {
      const result = minimax(newBoard, huPlayer);
      move.score = result.score;
    } else {
      const result = minimax(newBoard, aiPlayer);
      move.score = result.score;
    }

    newBoard[availSpots[i]] = '';
    moves.push(move);
  }

  let bestMove;
  if (player === aiPlayer) {
    let bestScore = -Infinity;
    for (let i = 0; i < moves.length; i++) {
      if (moves[i].score > bestScore) {
        bestScore = moves[i].score;
        bestMove = i;
      }
    }
  } else {
    let bestScore = Infinity;
    for (let i = 0; i < moves.length; i++) {
      if (moves[i].score < bestScore) {
        bestScore = moves[i].score;
        bestMove = i;
      }
    }
  }

  return moves[bestMove];
}

function checkWinState(boardState, player) {
  const winPatterns = [
    [0,1,2], [3,4,5], [6,7,8], // rader
    [0,3,6], [1,4,7], [2,5,8], // kolumner
    [0,4,8], [2,4,6]           // diagonaler
  ];

  return winPatterns.some(pattern =>
    pattern.every(index => boardState[index] === player)
  );
}
